# GUÍA DE DESPLIEGUE A PRODUCCIÓN (CIVILPROTECT AI)

## 1. REQUISITOS DEL SERVIDOR
Para un despliegue exitoso en un entorno Linux (recomendado: Ubuntu 22.04 LTS), se requiere:
*   **CPU:** 2 Cores mínimo.
*   **RAM:** 4GB mínimo (8GB recomendado para generación intensiva de PDFs).
*   **Espacio en Disco:** 20GB SSD.
*   **Python:** Versión 3.9 o superior.
*   **Node.js:** Versión 18 o superior.

## 2. PREPARACIÓN DEL ENTORNO (BACKEND)

### Paso A: Clonar Repositorio y Entorno Virtual
```bash
git clone https://github.com/tu-repo/civilprotect-ai.git
cd civilprotect-ai/backend
python3 -m venv venv
source venv/bin/activate
```

### Paso B: Instalación de Dependencias
```bash
pip install -r requirements.txt
# Asegurar dependencias de sistema para PDF
sudo apt-get install python3-dev libffi-dev cairo pango
```

### Paso C: Configuración de Variables de Entorno (.env)
Crear archivo `.env` en `/backend`:
```ini
PORT=8000
HOST=0.0.0.0
ALLOWED_ORIGINS=https://tu-dominio.com,http://localhost:3000
OPENAI_API_KEY=sk-.... (Si aplica)
```

### Paso D: Ejecución como Servicio (Systemd)
Crear `/etc/systemd/system/civilprotect-backend.service`:
```ini
[Unit]
Description=CivilProtect AI Backend
After=network.target

[Service]
User=ubuntu
WorkingDirectory=/home/ubuntu/civilprotect-ai/backend
ExecStart=/home/ubuntu/civilprotect-ai/backend/venv/bin/python main.py
Restart=always

[Install]
WantedBy=multi-user.target
```
Habilitar servicio: `sudo systemctl enable civilprotect-backend && sudo systemctl start civilprotect-backend`

---

## 3. PREPARACIÓN DEL FRONTEND

### Paso A: Build de Producción
```bash
cd ../frontend
npm install
# Configurar URL del API
echo "REACT_APP_API_URL=https://api.tu-dominio.com" > .env.production
npm run build
```

### Paso B: Servir con Nginx
Instalar Nginx: `sudo apt-get install nginx`
Configurar `/etc/nginx/sites-available/civilprotect`:
```nginx
server {
    listen 80;
    server_name tu-dominio.com;

    location / {
        root /home/ubuntu/civilprotect-ai/frontend/build;
        index index.html index.htm;
        try_files $uri $uri/ /index.html;
    }

    location /api/ {
        proxy_pass http://localhost:8000/; # Proxy al Backend
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
    }
}
```
Activar sitio: `sudo ln -s /etc/nginx/sites-available/civilprotect /etc/nginx/sites-enabled/`
Reiniciar Nginx: `sudo systemctl restart nginx`

---

## 4. CONSIDERACIONES DE SEGURIDAD
1.  **SSL/TLS:** Usar Certbot (`sudo apt-get install python3-certbot-nginx`) para activar HTTPS gratuito.
2.  **Firewall:** Cerrar puerto 8000 al público (solo accesible vía localhost para Nginx) y dejar abiertos solo 80 y 443.
3.  **Logs:** Supervisar logs en `journalctl -u civilprotect-backend -f`.

## 5. MANTENIMIENTO
*   Para actualizar normas: Editar `backend/data/legal_db.json`.
*   Para ajustar precios: Editar `manual_check.py` o módulo de precios.
