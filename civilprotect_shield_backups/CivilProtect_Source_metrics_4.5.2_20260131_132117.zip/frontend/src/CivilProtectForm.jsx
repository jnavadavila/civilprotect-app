import React from 'react';
import FormWizard from './components/FormWizard/FormWizard';

/**
 * CivilProtectForm (Wrapper)
 *
 * Este componente actúa como adaptador para mantener la compatibilidad con App.js
 * mientras se migra toda la lógica a FormWizard y sus sub-componentes.
 *
 * Refactorización Phase 3.1 completed.
 */
export default function CivilProtectForm(props) {
    return <FormWizard {...props} />;
}
